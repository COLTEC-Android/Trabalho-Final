package br.ufmg.coltec.poupapig;

import static org.junit.Assert.assertTrue;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.Before;
import org.junit.Test;

import br.ufmg.coltec.poupapig.Negócios.database.DatabaseHelper;

public class DatabaseHelperTest {
    private static final String TEST_DB_NAME = "test_db";

    private DatabaseHelper databaseHelper;
    private SQLiteDatabase database;

    @Before
    public void setUp() {

        Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();

        databaseHelper = new DatabaseHelper(context);

        database = databaseHelper.getWritableDatabase();
    }

    @Test
    public void testCreateCadastroTable() {
        databaseHelper.onCreate(database);
        assertTrue(isTableExists("cadastro"));
    }

    @Test
    public void testCreateSaldoTable() {
        databaseHelper.onCreate(database);
        assertTrue(isTableExists("saldo"));
    }

    @Test
    public void testCreateMetaTable() {
        databaseHelper.onCreate(database);
        assertTrue(isTableExists("meta"));
    }

    private boolean isTableExists(String tableName) {
        Cursor cursor = database.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name=?", new String[]{tableName});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }
}
