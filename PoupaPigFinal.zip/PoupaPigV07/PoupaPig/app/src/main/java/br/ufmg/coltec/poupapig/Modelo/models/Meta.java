package br.ufmg.coltec.poupapig.Modelo.models;

public class Meta {

    private int idCadastro;
    private String nome;
    private String descricao;
    private double valor;
    private double valorAcumulado;
    private String dataInicio;
    private String dataFim;

    //TODO descomentar se for o caso

//    public Meta(int idCadastro, String nome, String descricao, double valor, double valorAcumulado, String dataInicio, String dataFim) {
//        this.idCadastro = idCadastro;
//        this.nome = nome;
//        this.descricao = descricao;
//        this.valor = valor;
//        this.valorAcumulado = 0;
//        this.dataInicio = dataInicio;
//        this.dataFim = dataFim;
//    }

    public int getIdCadastro() {
        return idCadastro;
    }

    public void setIdCadastro(int idCadastro) {
        this.idCadastro = idCadastro;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public double getValorAcumulado() {
        return valorAcumulado;
    }

    public void setValorAcumulado(double valorAcumulado) {
        this.valorAcumulado = valorAcumulado;
    }

    public String getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(String dataInicio) {
        this.dataInicio = dataInicio;
    }

    public String getDataFim() {
        return dataFim;
    }

    public void setDataFim(String dataFim) {
        this.dataFim = dataFim;
    }
}
