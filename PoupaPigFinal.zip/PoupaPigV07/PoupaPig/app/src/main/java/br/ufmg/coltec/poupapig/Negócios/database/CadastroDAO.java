package br.ufmg.coltec.poupapig.Negócios.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import br.ufmg.coltec.poupapig.Modelo.models.Usuario;

public class CadastroDAO {

    private Context context;
    private DatabaseHelper databaseHelper;

    public CadastroDAO(Context context) {
        this.context = context;
        databaseHelper = new DatabaseHelper(context);
    }

    public long insereUsuario(Usuario usuario) {

        long resultado = -1; // valor caso ocorra algum erro

        DatabaseHelper databaseHelper = new DatabaseHelper(context);
        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        try {
            ContentValues values = new ContentValues();
            values.put("nome", usuario.getNome());
            values.put("email", usuario.getEmail());
            values.put("senha", usuario.getSenha());
            values.put("telefone", usuario.getTelefone());
            values.put("endereco", usuario.getEndereco());
            values.put("data_nascimento", usuario.getDataNascimento());
            values.put("genero", usuario.getGenero());

            resultado = db.insert("cadastro", null, values);

        }catch (SQLiteException e){
            e.printStackTrace();
        }finally {
            db.close();
        }

        return resultado;
    }

    public static boolean verificaUsuarioExistente(Context context, String email) {

        DatabaseHelper databaseHelper = new DatabaseHelper(context);
        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        String[] projection = { "email" }; // Extrai coluna desejada
        String selection = "email = ?";
        String[] selectionArgs = { email };

        Cursor cursor = db.query(
                "cadastro",
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        boolean usuarioExistente = cursor.getCount() > 0;

        cursor.close();
        db.close();

        return usuarioExistente;
    }

    public Usuario extrairDadosUsuario(int idUsuarioLogado) {

        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        String[] projection = {
                "nome",
                "email",
                "senha",
                "telefone",
                "endereco",
                "data_nascimento",
                "genero"
        };

        String selection = "idCadastro = ?";
        String[] selectionArgs = { String.valueOf(idUsuarioLogado) };

        Cursor cursor = db.query(
                "cadastro",
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        Usuario usuario = null;

        if (cursor.moveToFirst()) {
            int nomeIndex = cursor.getColumnIndexOrThrow("nome");
            int emailIndex = cursor.getColumnIndexOrThrow("email");
            int senhaIndex = cursor.getColumnIndexOrThrow("senha");
            int telefoneIndex = cursor.getColumnIndexOrThrow("telefone");
            int enderecoIndex = cursor.getColumnIndexOrThrow("endereco");
            int dataNascimentoIndex = cursor.getColumnIndexOrThrow("data_nascimento");
            int generoIndex = cursor.getColumnIndexOrThrow("genero");

            String nome = cursor.getString(nomeIndex);
            String email = cursor.getString(emailIndex);
            String senha = cursor.getString(senhaIndex);
            String telefone = cursor.getString(telefoneIndex);
            String endereco = cursor.getString(enderecoIndex);
            String data_nascimento = cursor.getString(dataNascimentoIndex);
            String genero = cursor.getString(generoIndex);

            usuario = new Usuario(nome, email, senha, telefone, endereco, data_nascimento, genero);
        }

        cursor.close();
        db.close();

        return usuario;
    }

    public long atualizarUsuario(Usuario usuario, int idLogado) {

        long resultado = -1; // caso de erro

        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        try{
            ContentValues values = new ContentValues();
            values.put("nome", usuario.getNome());
            values.put("email", usuario.getEmail());
            values.put("senha", usuario.getSenha());
            values.put("telefone", usuario.getTelefone());
            values.put("endereco", usuario.getEndereco());
            values.put("data_nascimento", usuario.getDataNascimento());
            values.put("genero", usuario.getGenero());
            resultado = db.update("cadastro", values, "idCadastro = " + idLogado, null);

        }catch (SQLiteException e){
            e.printStackTrace();
        }finally {
            db.close();
        }

        return resultado;
    }
}