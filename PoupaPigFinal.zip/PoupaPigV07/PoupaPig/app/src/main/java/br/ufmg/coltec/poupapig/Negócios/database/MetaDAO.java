package br.ufmg.coltec.poupapig.Negócios.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import java.util.ArrayList;

import br.ufmg.coltec.poupapig.Modelo.models.Meta;

public class MetaDAO {

    private Context context;
    private DatabaseHelper databaseHelper;

    public MetaDAO(Context context) {
        this.context = context;
        databaseHelper = new DatabaseHelper(context);
    }

    public long inserirMeta(Meta meta, int idLogado) {

        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        long resultado = -1;

        try{
            ContentValues values = new ContentValues();
            values.put("idCadastro", idLogado);
            values.put("nome", meta.getNome());
            values.put("descricao", meta.getDescricao());
            values.put("valor", meta.getValor());
            values.put("valorAcumulado", meta.getValorAcumulado());
            values.put("dataInicio", meta.getDataInicio());
            values.put("dataFim", meta.getDataFim());

            resultado = db.insert("meta", null, values);

        }catch (SQLiteException e){
            e.printStackTrace();
        }finally {
            db.close();
        }

        return resultado;
    }

    public Meta extrairMeta(int idUsuarioLogado, int idMeta) {

        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        String[] projection = {
                "nome",
                "descricao",
                "valor",
                "valorAcumulado",
                "dataInicio",
                "dataFim"
        };

        String selection = "idCadastro = ? AND idMeta = ?";
        String[] selectionArgs = { String.valueOf(idUsuarioLogado), String.valueOf(idMeta) };
        Cursor cursor = db.query(
                "meta",
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        Meta meta = null;

        if (cursor.moveToFirst()) {
            int nomeIndex = cursor.getColumnIndexOrThrow("nome");
            int descricaoIndex = cursor.getColumnIndexOrThrow("descricao");
            int valorIndex = cursor.getColumnIndexOrThrow("valor");
            int valorAcumuladoIndex = cursor.getColumnIndexOrThrow("valorAcumulado");
            int dataInicioIndex = cursor.getColumnIndexOrThrow("dataInicio");
            int dataFimIndex = cursor.getColumnIndexOrThrow("dataFim");

            String nome = cursor.getString(nomeIndex);
            String descricao = cursor.getString(descricaoIndex);
            double valor = cursor.getDouble(valorIndex);
            double valorAcumulado = cursor.getDouble(valorAcumuladoIndex);
            String dataInicio = cursor.getString(dataInicioIndex);
            String dataFim = cursor.getString(dataFimIndex);

            //TODO ***SEM** construtor
            meta = new Meta ();
            meta.setNome(nome);
            meta.setDescricao(descricao);
            meta.setValor(valor);
            meta.setValorAcumulado(valorAcumulado);
            meta.setDataInicio(dataInicio);
            meta.setDataFim(dataFim);
        }

        cursor.close();
        db.close();

        return meta;
    }

    public ArrayList<Meta> extrairMetaList(int idUsuarioLogado) {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        String[] projection = {
                "nome",
                "descricao",
                "valor",
                "valorAcumulado",
                "dataInicio",
                "dataFim"
        };

        String selection = "idCadastro = ?";
        String[] selectionArgs = { String.valueOf(idUsuarioLogado) };

        Cursor cursor = db.query(
                "meta",
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        ArrayList<Meta> metas = new ArrayList<>();

        while (cursor.moveToNext()) {
            String nome = cursor.getString(cursor.getColumnIndexOrThrow("nome"));
            String descricao = cursor.getString(cursor.getColumnIndexOrThrow("descricao"));
            double valor = cursor.getDouble(cursor.getColumnIndexOrThrow("valor"));
            double valorAcumulado = cursor.getDouble(cursor.getColumnIndexOrThrow("valorAcumulado"));
            String dataInicio = cursor.getString(cursor.getColumnIndexOrThrow("dataInicio"));
            String dataFim = cursor.getString(cursor.getColumnIndexOrThrow("dataFim"));

            Meta meta = new Meta();
            meta.setNome(nome);
            meta.setDescricao(descricao);
            meta.setValor(valor);
            meta.setValorAcumulado(valorAcumulado);
            meta.setDataInicio(dataInicio);
            meta.setDataFim(dataFim);

            metas.add(meta);
        }

        cursor.close();
        db.close();

        return metas;
    }

    public long atualizarMeta(double valor) {

        long resultado = -1; // caso de erro

        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        try{
            ContentValues values = new ContentValues();
            values.put("valorAcumulado", valor);
            resultado = db.update("meta", values, null, null);

            db.close();
        }catch (SQLiteException e){
            e.printStackTrace();
        }

        return resultado;
    }

    public double obterValorAcumulado(int idUsuarioLogado, int idMeta) {

        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        String[] projection = { "valorAcumulado" };
        String selection = "idCadastro = ? AND idMeta = ?";
        String[] selectionArgs = {String.valueOf(idUsuarioLogado), String.valueOf(idUsuarioLogado)};
        String sortOrder = null;

        Cursor cursor = db.query(
                "meta",
                projection,
                selection,
                selectionArgs,
                null,
                null,
                sortOrder
        );

        double valorAcumulado = 0;

        if (cursor.moveToFirst()) {
            int valorAcumuladoIndex = cursor.getColumnIndexOrThrow("valorAcumulado");
            valorAcumulado = cursor.getDouble(valorAcumuladoIndex);
        }

        cursor.close();

        return valorAcumulado;
    }
}
