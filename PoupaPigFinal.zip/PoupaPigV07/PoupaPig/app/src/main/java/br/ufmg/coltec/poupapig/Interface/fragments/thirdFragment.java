package br.ufmg.coltec.poupapig.Interface.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import br.ufmg.coltec.poupapig.Negócios.database.CadastroDAO;
import br.ufmg.coltec.poupapig.Interface.activities.MainActivity;
import br.ufmg.coltec.poupapig.R;
import br.ufmg.coltec.poupapig.Modelo.models.Usuario;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link thirdFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class thirdFragment extends Fragment {

    private EditText edtNome;
    private EditText edtEmail;
    private EditText edtSenha;
    private EditText edtTelefone;
    private EditText edtDataNascimento;
    private EditText edtEndereco;
    private RadioButton radioButtonFeminino;
    private RadioButton radioButtonMasculino;
    private RadioButton radioButtonOutro;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public thirdFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment thirdFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static thirdFragment newInstance(String param1, String param2) {
        thirdFragment fragment = new thirdFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_third, container, false);

        edtNome = view.findViewById(R.id.editTextNome);
        edtEmail = view.findViewById(R.id.editTextEmail);
        edtSenha = view.findViewById(R.id.editTextSenha);
        edtTelefone = view.findViewById(R.id.editTextTelefone);
        edtDataNascimento = view.findViewById(R.id.editTextDataNascimento);
        edtEndereco = view.findViewById(R.id.editTextEndereco);
        radioButtonMasculino = view.findViewById(R.id.radioButtonMasculino);
        radioButtonFeminino = view.findViewById(R.id.radioButtonFeminino);
        radioButtonOutro = view.findViewById(R.id.radioButtonOutro);
        Button btn_editar = view.findViewById(R.id.btnEditar);
        Button btn_salvar = view.findViewById(R.id.btnSalvar);
        Button btn_sair = view.findViewById(R.id.btnSair);

        CadastroDAO cadastroDAO = new CadastroDAO(getContext());

        // Extrai os dados do usuário do banco de dados
        Usuario usuario = cadastroDAO.extrairDadosUsuario(2);
        if (usuario != null) {
            edtNome.setText(usuario.getNome());
            edtEmail.setText(usuario.getEmail());
            edtSenha.setText(usuario.getSenha());
            edtTelefone.setText(usuario.getTelefone());
            edtEndereco.setText(usuario.getEndereco());
            edtDataNascimento.setText(usuario.getDataNascimento());

            if (usuario.getGenero().equals("Masculino")) {
                radioButtonMasculino.setChecked(true);
            } else if (usuario.getGenero().equals("Feminino")) {
                radioButtonFeminino.setChecked(true);
            } else {
                radioButtonOutro.setChecked(true);
            }
        }

        btn_editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Habilita a edição dos editText
                edtNome.setEnabled(true);
                edtEmail.setEnabled(true);
                edtSenha.setEnabled(true);
                edtTelefone.setEnabled(true);
                edtEndereco.setEnabled(true);
                edtDataNascimento.setEnabled(true);
                radioButtonFeminino.setEnabled(true);
                radioButtonMasculino.setEnabled(true);
                radioButtonOutro.setEnabled(true);

                // Habilita o botão salvar
                btn_salvar.setEnabled(true);
            }
        });

        btn_salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Usuario usuarioAtualizado = new Usuario(
                        edtNome.getText().toString(),
                        edtEmail.getText().toString(),
                        edtSenha.getText().toString(),
                        edtTelefone.getText().toString(),
                        edtEndereco.getText().toString(),
                        edtDataNascimento.getText().toString(),
                        radioButtonMasculino.isChecked() ? "Masculino" : radioButtonFeminino.isChecked() ? "Feminino" : "Outro"
                );

                if(cadastroDAO.atualizarUsuario(usuarioAtualizado, 2) != -1){
                    Toast.makeText(getContext(), "Perfil atualizado com sucesso!", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getContext(), "Erro ao atualizar perfil.", Toast.LENGTH_SHORT).show();
                }

                edtNome.setEnabled(false);
                edtEmail.setEnabled(false);
                edtSenha.setEnabled(false);
                edtTelefone.setEnabled(false);
                edtEndereco.setEnabled(false);
                edtDataNascimento.setEnabled(false);
                radioButtonFeminino.setEnabled(false);
                radioButtonMasculino.setEnabled(false);
                radioButtonOutro.setEnabled(false);
                btn_salvar.setEnabled(false);
            }
        });

        btn_sair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                requireActivity().finish();
            }
        });

        return view;
    }
}