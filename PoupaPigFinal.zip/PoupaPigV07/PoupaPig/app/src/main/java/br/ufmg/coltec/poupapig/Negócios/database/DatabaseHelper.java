package br.ufmg.coltec.poupapig.Negócios.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Criação da tabela para armazenar os dados de usuário

        String createCadastroTableQuery = "CREATE TABLE cadastro (" +
                "idCadastro INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nome TEXT," +
                "email TEXT," +
                "senha TEXT," +
                "telefone TEXT," +
                "endereco TEXT," +
                "data_nascimento TEXT," +
                "genero TEXT)";

        db.execSQL(createCadastroTableQuery);

        String createSaldoTableQuery = "CREATE TABLE saldo (" +
                "idSaldo INTEGER PRIMARY KEY AUTOINCREMENT," +
                "idCadastro INTEGER," +
                "valor REAL," +
                "FOREIGN KEY (idCadastro) REFERENCES cadastro (idCadastro))";

        db.execSQL(createSaldoTableQuery);

        String createMetaTableQuery = "CREATE TABLE meta (" +
                "idMeta INTEGER PRIMARY KEY AUTOINCREMENT," +
                "idCadastro INTEGER, " +
                "nome TEXT," +
                "descricao TEXT," +
                "valor REAL," +
                "valorAcumulado REAL," +
                "dataInicio TEXT," +
                "dataFim TEXT," +
                "FOREIGN KEY (idCadastro) REFERENCES cadastro (idCadastro))";

        db.execSQL(createMetaTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}