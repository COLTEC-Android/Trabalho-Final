package br.ufmg.coltec.poupapig.Negócios.database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

public class LoginDAO {

    private static int idUsuarioLogado = -1;
    public static int verificaLogin(Context context, String email, String senha) {

        DatabaseHelper databaseHelper = new DatabaseHelper(context);
        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        String[] projection = {
                "idCadastro"
        };

        String selection = "email = ? AND senha = ?";
        String[] selectionArgs = { email, senha };

        Cursor cursor = db.query(
                "cadastro",
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        //boolean loginValido = cursor.getCount() > 0;

        //idUsuarioLogado = -1; // valor caso o login seja inválido

        if (cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndexOrThrow("idCadastro");
            idUsuarioLogado = cursor.getInt(idIndex);
        }

        cursor.close();
        db.close();

        //return loginValido;
        Toast.makeText(context, "ID USUARIO LOGADO = " + idUsuarioLogado, Toast.LENGTH_SHORT).show();
        return idUsuarioLogado;
    }

    //TODO testar
    public static int getIdUsuarioLogado() {
        return idUsuarioLogado;
    }
}