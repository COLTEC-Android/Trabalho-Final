package br.ufmg.coltec.poupapig.Interface.fragments;

import android.app.AlertDialog;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import br.ufmg.coltec.poupapig.Negócios.database.LoginDAO;
import br.ufmg.coltec.poupapig.R;
import br.ufmg.coltec.poupapig.Modelo.models.Saldo;
import br.ufmg.coltec.poupapig.Negócios.database.SaldoDAO;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link firstFragment#newInstance} factory method to
 * create an instance of this fragment.
 *
 */
public class firstFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment homeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static firstFragment newInstance(String param1, String param2) {
        firstFragment fragment = new firstFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    public firstFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);


        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_first, container, false);

        SaldoDAO saldoDAO = new SaldoDAO(getContext());

        TextView txt_saldo = view.findViewById(R.id.txtSaldo);

        CardView cardAdd = view.findViewById(R.id.cardAdicionar);
        CardView cardSub = view.findViewById(R.id.cardRetirar);

        //TODO verificar idUsuarioLogado

        double saldoAtual = saldoDAO.obterSaldoAtual(2);

        // Coloca saldo do usuário na tela
        txt_saldo.setText(String.valueOf("R$ " + saldoAtual));

        cardAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Adicionar valor");

                LayoutInflater inflater = getLayoutInflater();
                View dialogView = inflater.inflate(R.layout.layout_dialog_adicionar, null);
                builder.setView(dialogView);

                EditText edtAddSaldo = dialogView.findViewById(R.id.editTextAddSaldo);
                Button btn_ok = dialogView.findViewById(R.id.btnOkAdd);

                AlertDialog dialog = builder.create();

                btn_ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        //TODO teste ID

                        int idUsuarioLogado = LoginDAO.getIdUsuarioLogado();

                        // Obtem o valor digitado no EditText
                        String inputText = edtAddSaldo.getText().toString();

                        if (!inputText.isEmpty()) {
                            // Converte o valor para double
                            double valor = Double.parseDouble(inputText);

                            //double saldoAtual = saldoDAO.obterSaldoAtual(2);
                            //double novoSaldo = 0 + valor;

                            try {
                                Saldo saldo = new Saldo(2, valor);
                                long resultado = saldoDAO.insereSaldo(saldo);

                                if (resultado != -1) {
                                    Toast.makeText(getContext(), "Valor adicionado com sucesso!", Toast.LENGTH_SHORT).show();
                                }
                                else{
                                    Toast.makeText(getContext(), "Erro ao adicionar valor.", Toast.LENGTH_SHORT).show();

                                }
                            }catch (SQLiteException e){
                                e.printStackTrace();
                                System.out.println("Erro-INSERT Saldo: " + e.getMessage());
                            }

                        }else{
                            Toast.makeText(getContext(), "Valor inserido inválido", Toast.LENGTH_SHORT).show();
                        }

                        // Fechar o Dialog
                        dialog.dismiss();
                    }

                });

                dialog.show();

            }
        });

        cardSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Retirar Valor");

                LayoutInflater inflater = getLayoutInflater();

                View dialogView = inflater.inflate(R.layout.layout_dialog_retirar, null);
                builder.setView(dialogView);

                EditText edtSubSaldo = dialogView.findViewById(R.id.editTextSubSaldo);
                Button btn_ok_retirar = dialogView.findViewById(R.id.btnOkSub);

                AlertDialog dialog = builder.create();

                btn_ok_retirar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        String valorRetirarStr = edtSubSaldo.getText().toString();

                        if (!valorRetirarStr.isEmpty()) {
                            double valorRetirar = Double.parseDouble(valorRetirarStr);

                            double saldoAtual = saldoDAO.obterSaldoAtual(2);

                            if (valorRetirar <= saldoAtual) {
                                try {
                                    Saldo saldo = new Saldo(2, valorRetirar);
                                    double novoSaldo = saldoAtual - valorRetirar;
                                    long resultado = saldoDAO.atualizarSaldo(novoSaldo);

                                    if (resultado != -1) {
                                        Toast.makeText(getContext(), "Valor retirado com sucesso!", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(getContext(), "Erro ao retirar valor.", Toast.LENGTH_SHORT).show();

                                    }
                                } catch (SQLiteException e) {
                                    e.printStackTrace();
                                    System.out.println("Erro-SUB Saldo: " + e.getMessage());
                                }
                            }

                        }
                    }

                });

                dialog.show();
            }
        });

        return view;
    }
}