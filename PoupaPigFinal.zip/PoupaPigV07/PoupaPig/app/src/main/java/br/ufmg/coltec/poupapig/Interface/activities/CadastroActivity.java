package br.ufmg.coltec.poupapig.Interface.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import br.ufmg.coltec.poupapig.Negócios.database.CadastroDAO;
import br.ufmg.coltec.poupapig.R;
import br.ufmg.coltec.poupapig.Modelo.models.Usuario;

public class CadastroActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        CadastroDAO cadastroDAO = new CadastroDAO(this);

        EditText lblNome = findViewById(R.id.edtNome);
        EditText lblEmail = findViewById(R.id.edtEmail);
        EditText lblSenha = findViewById(R.id.edtSenha);
        EditText lblTelefone = findViewById(R.id.edtTelefone);
        EditText lblEndereco = findViewById(R.id.edtEndereco);
        EditText lblNascimento = findViewById(R.id.edtNascimento);
        RadioButton radioButtonMasculino = findViewById(R.id.radioButtonMasculino);
        RadioButton radioButtonFeminino = findViewById(R.id.radioButtonFeminino);
        RadioButton radioButtonOutro = findViewById(R.id.radioButtonOutro);
        Button btn_cadastrar = findViewById(R.id.btnCadastrar);

        btn_cadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String nome = lblNome.getText().toString();
                String email = lblEmail.getText().toString();
                String senha = lblSenha.getText().toString();
                String telefone = lblTelefone.getText().toString();
                String endereco = lblEndereco.getText().toString();
                String dataNascimento = lblNascimento.getText().toString();
                String genero;

                if (radioButtonMasculino.isChecked()) {
                    genero = "Masculino";
                } else if (radioButtonFeminino.isChecked()) {
                    genero = "Feminino";
                } else {
                    genero = "Outro";
                }

                if(nome.isEmpty() || email.isEmpty() || senha.isEmpty()){
                    Toast.makeText(CadastroActivity.this, "Preencha os campos corretamente", Toast.LENGTH_SHORT).show();
                }
                else{
                    try {
                        if (cadastroDAO.verificaUsuarioExistente(CadastroActivity.this, email)) {
                            // TODO ver se com DIALOG fica melhor
                            Toast.makeText(CadastroActivity.this, "O e-mail inserido já está em uso.", Toast.LENGTH_SHORT).show();
                        } else {
                            // Cria um objeto Usuario com os dados inseridos
                            Usuario usuario = new Usuario(nome, email, senha, telefone, endereco, dataNascimento, genero);

                            // Insere o usuário no banco de dados
                            long resultado = cadastroDAO.insereUsuario(usuario);

                            if (resultado != -1) {
                                Toast.makeText(CadastroActivity.this, "Usuário cadastrado com sucesso!", Toast.LENGTH_SHORT).show();
                                finish();
                            } else {
                                Toast.makeText(CadastroActivity.this, "Erro ao cadastrar usuário!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    } catch (SQLiteException e){
                        e.printStackTrace();
                        System.out.println("ERRO-Cadastro de usuário: " + e.getMessage());
                    }
                    finish();
                }

            }
        });
    }
}