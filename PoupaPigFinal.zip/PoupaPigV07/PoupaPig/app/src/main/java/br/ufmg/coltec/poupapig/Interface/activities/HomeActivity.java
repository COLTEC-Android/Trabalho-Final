package br.ufmg.coltec.poupapig.Interface.activities;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import android.view.MenuItem;

import br.ufmg.coltec.poupapig.R;
import br.ufmg.coltec.poupapig.Interface.fragments.firstFragment;
import br.ufmg.coltec.poupapig.Interface.fragments.secondFragment;
import br.ufmg.coltec.poupapig.Interface.fragments.thirdFragment;

public class HomeActivity extends AppCompatActivity
        implements BottomNavigationView.OnItemSelectedListener  {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

    }

    protected void onResume(){

        super.onResume();

        BottomNavigationView bottomNavigationView = this.findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnItemSelectedListener(this);
        bottomNavigationView.setSelectedItemId(R.id.carteira);

    }

    br.ufmg.coltec.poupapig.Interface.fragments.firstFragment firstFragment = new firstFragment();
    br.ufmg.coltec.poupapig.Interface.fragments.secondFragment secondFragment = new secondFragment();
    br.ufmg.coltec.poupapig.Interface.fragments.thirdFragment thirdFragment = new thirdFragment();

    @Override
    public boolean onNavigationItemSelected(MenuItem item){

        switch (item.getItemId()) {

            case R.id.carteira:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.flFragment, firstFragment)
                        .commit();
                return true;

            case R.id.metas:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.flFragment, secondFragment)
                        .commit();
                return true;

            case R.id.perfil:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.flFragment, thirdFragment)
                        .commit();
                return true;
        }
        return false;
    }
}
