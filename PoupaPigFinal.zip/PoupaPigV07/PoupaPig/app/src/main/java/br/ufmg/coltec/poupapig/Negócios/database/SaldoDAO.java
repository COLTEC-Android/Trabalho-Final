package br.ufmg.coltec.poupapig.Negócios.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import br.ufmg.coltec.poupapig.Modelo.models.Saldo;

public class SaldoDAO {

    private Context context;
    DatabaseHelper databaseHelper = new DatabaseHelper(context);

    public SaldoDAO(Context context) {
        this.context = context;
        databaseHelper = new DatabaseHelper(context);
    }

    public long insereSaldo(Saldo saldo) {

        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        long resultado = -1; // valor para caso de erro

        // TODO verificar ID
        Double novoSaldo = saldo.getValor() + obterSaldoAtual(2);

        try {
            String query = "SELECT COUNT(*) FROM saldo WHERE idCadastro = ?";
            String[] selectionArgs = {String.valueOf(saldo.getIdCadastro())};
            Cursor cursor = db.rawQuery(query, selectionArgs);

            if (cursor.moveToFirst()) {
                int count = cursor.getInt(0);
                if (count > 0) {
                    resultado = atualizarSaldo(novoSaldo);
                } else {
                    ContentValues values = new ContentValues();
                    values.put("idCadastro", saldo.getIdCadastro());
                    values.put("valor", saldo.getValor());
                    resultado = db.insert("saldo", null, values);
                }
            }
            cursor.close();
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            db.close();
        }

        return resultado;
    }

    public double obterSaldoAtual(int idUsuarioLogado) {

        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        String[] projection = { "valor" };
        String selection = "idCadastro = ?";
        String[] selectionArgs = {String.valueOf(idUsuarioLogado)};
        String sortOrder = null;

        Cursor cursor = db.query(
                "saldo",
                projection,
                selection,
                selectionArgs,
                null,
                null,
                sortOrder
        );

        double saldoAtual = 0;

        if (cursor.moveToFirst()) {
            int saldoIndex = cursor.getColumnIndexOrThrow("valor");
            saldoAtual = cursor.getDouble(saldoIndex);
        }

        cursor.close();
        //db.close();

        return saldoAtual;
    }

    public long atualizarSaldo(double novoSaldo) {

        long resultado = -1; // caso de erro

        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        try{
            ContentValues values = new ContentValues();
            values.put("valor", novoSaldo);
            resultado = db.update("saldo", values, null, null);

            db.close();
        }catch (SQLiteException e){
            e.printStackTrace();
        }

        return resultado;
    }
}
