package br.ufmg.coltec.poupapig.Interface.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.ArrayList;

import br.ufmg.coltec.poupapig.Modelo.models.Meta;
import br.ufmg.coltec.poupapig.Negócios.database.MetaDAO;
import br.ufmg.coltec.poupapig.R;
import br.ufmg.coltec.poupapig.Negócios.database.SaldoDAO;

public class MetaAdapter extends RecyclerView.Adapter<MetaAdapter.ViewHolder> {
    private ArrayList<Meta> metaArrayList;
    private Context context;

    public MetaAdapter(ArrayList<Meta> metaArrayList, Context context) {
        this.metaArrayList = metaArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public MetaAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MetaAdapter.ViewHolder holder, int position) {

        Meta meta = metaArrayList.get(position);
        holder.txtTitulo.setText(meta.getNome());
        holder.progressBar.setProgress(0);
        holder.txtValorAcumulado.setText(String.valueOf("R$ " + meta.getValorAcumulado() + " / "));
        holder.txtValor.setText(String.valueOf(meta.getValor()));
        holder.txtDataFim.setText(meta.getDataFim());
        holder.icon.setImageResource(R.drawable.pig3);

        CardView cardMetas = holder.itemView.findViewById(R.id.cardView);
        Button btnAdicionaValorMeta = holder.itemView.findViewById(R.id.btnAdicionarValorMeta);

        cardMetas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context);

                LayoutInflater inflater = LayoutInflater.from(context);

                View bottomSheetView = inflater.inflate(R.layout.bottom_sheet_layout, null);

                // Recupera componentes
                EditText bsTitulo = bottomSheetView.findViewById(R.id.bsTitulo);
                EditText bsDescricao = bottomSheetView.findViewById(R.id.bsDescricao);
                EditText bsValor = bottomSheetView.findViewById(R.id.bsValor);
                EditText bsDataInicio = bottomSheetView.findViewById(R.id.bsDataInicio);
                EditText bsDataFim = bottomSheetView.findViewById(R.id.bsDataFim);

                MetaDAO metaDAO = new MetaDAO(context);
                // TODO **VERIFICAR**
                //MetaDAO metaDAO = new MetaDAO();
                // long idMetaInserida = inserirMeta(metaArrayList.get(position), idUsuarioLogado);

                Meta meta = metaDAO.extrairMeta(2, 2);

                if(meta != null){
                    bsTitulo.setText(meta.getNome());
                    bsDescricao.setText(meta.getDescricao());
                    bsValor.setText(String.valueOf(meta.getValor()));
                    bsDataInicio.setText(meta.getDataInicio());
                    bsDataFim.setText(meta.getDataFim());

                    bottomSheetDialog.setContentView(bottomSheetView);
                    bottomSheetDialog.show();

                }else{
                    Toast.makeText(context, "Meta não encontrada!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnAdicionaValorMeta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Adicionar valor à Meta");

                LayoutInflater inflater = LayoutInflater.from(context);
                View dialogView = inflater.inflate(R.layout.layout_dialog_adicionar, null);
                builder.setView(dialogView);

                EditText edtAddSaldo = dialogView.findViewById(R.id.editTextAddSaldo);
                Button btnOk = dialogView.findViewById(R.id.btnOkAdd);

                AlertDialog dialog = builder.create();

                dialog.show();

                btnOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        // Recupera valor inserido e converte para Double
                        String valor = edtAddSaldo.getText().toString();
                        double valorDouble = Double.parseDouble(valor);

                        SaldoDAO saldoDAO = new SaldoDAO(context);
                        MetaDAO metaDAO = new MetaDAO(context);
                        Double saldoAtual = saldoDAO.obterSaldoAtual(2);
                        Double valorAcumulado = metaDAO.obterValorAcumulado(2, 2);
                        Double atualizaSaldo = saldoAtual - valorDouble;
                        double atualizaValor = valorAcumulado + valorDouble;

                        int progresso = (int) ((atualizaValor * 100.0) / saldoAtual);

                        if(valorDouble > saldoAtual){
                            Toast.makeText(context, "Valor inválido!", Toast.LENGTH_SHORT).show();
                        }
                        //TODO verificacao quando a meta estiver sendo batida
                        else{
                            metaDAO.atualizarMeta(valorDouble);
                            Toast.makeText(context, "Valor adicionado com sucesso!", Toast.LENGTH_SHORT).show();
                            saldoDAO.atualizarSaldo(atualizaSaldo);

                            // Atualiza barra de progresso
                            holder.progressBar.setProgress(progresso);
                        }
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return metaArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView txtTitulo;
        private ProgressBar progressBar;
        private TextView txtValor;
        private TextView txtValorAcumulado;
        private TextView txtDataFim;
        private ImageView icon;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtTitulo = itemView.findViewById(R.id.textViewTitulo);
            progressBar = itemView.findViewById(R.id.progressBar);
            txtValor = itemView.findViewById(R.id.textViewValor);
            txtValorAcumulado = itemView.findViewById(R.id.textViewValorAcumulado);
            txtDataFim = itemView.findViewById(R.id.textViewDataFim);
            icon = itemView.findViewById(R.id.imageViewIcon);
        }
    }
}
