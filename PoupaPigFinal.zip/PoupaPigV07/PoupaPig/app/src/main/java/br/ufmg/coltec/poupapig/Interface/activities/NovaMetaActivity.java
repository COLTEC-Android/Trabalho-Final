package br.ufmg.coltec.poupapig.Interface.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import br.ufmg.coltec.poupapig.Modelo.models.Meta;
import br.ufmg.coltec.poupapig.Negócios.database.MetaDAO;
import br.ufmg.coltec.poupapig.R;

public class NovaMetaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nova_meta);

        EditText edtTitulo = findViewById(R.id.editTextTitulo);
        EditText edtDescricao = findViewById(R.id.editTextDescricao);
        EditText edtValor = findViewById(R.id.editTextValor);
        EditText edtDataIni = findViewById(R.id.editTextDataInicio);
        EditText edtDataFim = findViewById(R.id.editTextDataFim);
        Button btn_salvar = findViewById(R.id.btnSalvar);

        btn_salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                MetaDAO metaDAO = new MetaDAO(getApplicationContext());

                // TODO  METODO COM CONSTRUTOR
//                Meta novaMeta = new Meta(
//                        2,
//                        edtTitulo.getText().toString(),
//                        edtDescricao.getText().toString(),
//                        Double.parseDouble(edtValor.getText().toString()),
//                        0,
//                        edtDataIni.getText().toString(),
//                        edtDataFim.getText().toString()
//                );

                //TODO METODO ***SEM*** CONSTRUTOR

                Meta novaMeta = new Meta();
                novaMeta.setNome(edtTitulo.getText().toString());
                novaMeta.setDescricao(edtDescricao.getText().toString());
                novaMeta.setValor(Double.parseDouble(edtValor.getText().toString()));
                novaMeta.setValorAcumulado(0);
                novaMeta.setDataInicio(edtDataIni.getText().toString());
                novaMeta.setDataFim(edtDataFim.getText().toString());

                if(metaDAO.inserirMeta(novaMeta, 2) != -1){
                    Toast.makeText(NovaMetaActivity.this, "Meta adicionada com sucesso!", Toast.LENGTH_SHORT).show();
                    finish();
                }else{
                    Toast.makeText(NovaMetaActivity.this, "Erro ao adicionar meta.", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}