package br.ufmg.coltec.poupapig.Modelo.models;

public class Saldo {

    private int idCadastro;
    private double valor;

    public Saldo(int idCadastro, double valor) {
        this.idCadastro = idCadastro;
        this.valor = valor;
    }

    public int getIdCadastro() {
        return idCadastro;
    }

    public void setIdCadastro(int idCadastro) {
        this.idCadastro = idCadastro;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
}
