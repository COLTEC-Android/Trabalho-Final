package br.ufmg.coltec.poupapig.Interface.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import br.ufmg.coltec.poupapig.Negócios.database.LoginDAO;
import br.ufmg.coltec.poupapig.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText lblEmail = findViewById(R.id.edtEmail);
        EditText lblSenha = findViewById(R.id.edtSenha);
        Button btn_entrar = findViewById(R.id.btnEntrar);
        TextView lblCadastrar = findViewById(R.id.txtCadastrar);

        btn_entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email = lblEmail.getText().toString();
                String senha = lblSenha.getText().toString();

                try {
                    if (LoginDAO.verificaLogin(getApplicationContext(), email, senha) != -1) {
                        // Login bem-sucedido
                        Toast.makeText(MainActivity.this, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                        startActivity(intent);
                    } else {
                        // Login inválido
                        Toast.makeText(MainActivity.this, "Email ou senha inválidos!", Toast.LENGTH_SHORT).show();
                    }
                } catch (SQLiteException e) {
                    e.printStackTrace();
                    System.out.println("ERRO-Autenticação: " + e.getMessage());
                }

            }
        });

        lblCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Abre tela de cadastro
                Intent intent = new Intent(MainActivity.this, CadastroActivity.class);
                startActivity(intent);
            }
        });

    }
}