package com.example.trabalho.Interface;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.trabalho.Modelo.DatabaseHelper;
import com.example.trabalho.Modelo.Filme;
import com.example.trabalho.Negocio.FilmeAdapter;
import com.example.trabalho.Negocio.WatchListPresenter;
import com.example.trabalho.R;

import java.util.List;


public class WatchlistActivity extends AppCompatActivity {

    private ListView listView;
    private WatchListPresenter watchListPresenter;
    private FilmeAdapter adapter;
    private int idUsuario;
    private int idTema;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        idTema = getIntent().getIntExtra("idTema", 0);
        this.setTheme(idTema);
        setContentView(R.layout.activity_watchlist);

        idUsuario = getIntent().getIntExtra("idUsuario", 0);

        listView = findViewById(R.id.listView);
        DatabaseHelper db = new DatabaseHelper(this);
        watchListPresenter = new WatchListPresenter(db, this);

        adapter = new FilmeAdapter(WatchlistActivity.this, carregarFilmes());
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Filme fimeSelecionado = (Filme) parent.getItemAtPosition(position);
                int filmeId = fimeSelecionado.getId();

                Intent intent = new Intent(WatchlistActivity.this, DetalhesFilmeActivity.class);
                intent.putExtra("filmeId", filmeId);
                intent.putExtra("idUsuario", idUsuario);
                intent.putExtra("idTema", idTema);
                startActivity(intent);
            }
        });
    }

    private List<Filme> carregarFilmes() {
        return watchListPresenter.getFilmesWatchlist(idUsuario);
    }
}