package com.example.trabalho.Negocio;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.trabalho.Modelo.Filme;
import com.example.trabalho.R;

import java.util.List;

public class FilmeAdapter extends ArrayAdapter<Filme> {
    private LayoutInflater inflater;
    private List<Filme> filmes;

    public FilmeAdapter(Context context, List<Filme> filmes) {
        super(context, R.layout.activity_filme, filmes);
        this.filmes = filmes;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.activity_filme, parent, false);
            holder = new ViewHolder();
            holder.titleTextView = convertView.findViewById(R.id.titleTextView);
            holder.originalTitleTextView = convertView.findViewById(R.id.originalTitleTextView);
            holder.releaseDateTextView = convertView.findViewById(R.id.releaseDateTextView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Filme filme = filmes.get(position);
        holder.titleTextView.setText(filme.getTitle());
        holder.originalTitleTextView.setText(filme.getOriginal_title());
        holder.releaseDateTextView.setText(filme.getRelease_date());

        return convertView;
    }

    private static class ViewHolder {
        TextView titleTextView;
        TextView originalTitleTextView;
        TextView releaseDateTextView;
    }
}
