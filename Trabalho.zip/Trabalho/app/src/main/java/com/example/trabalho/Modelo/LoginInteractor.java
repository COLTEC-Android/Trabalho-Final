package com.example.trabalho.Modelo;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class LoginInteractor {
    private DatabaseHelper databaseHelper;

    public LoginInteractor(DatabaseHelper db) {
        this.databaseHelper = db;
    }

    public Usuario performLogin(String username, String password) {
        try {
            SQLiteDatabase db = databaseHelper.getReadableDatabase();

            String[] columns = {DatabaseHelper.COLUMN_ID, DatabaseHelper.COLUMN_USERNAME};

            String selection = DatabaseHelper.COLUMN_USERNAME + " = ? AND " + DatabaseHelper.COLUMN_PASSWORD + " = ?";

            String[] selectionArgs = {username, password};

            Cursor cursor = db.query(DatabaseHelper.TABLE_NAME_USER, columns, selection, selectionArgs,
                    null, null, null);
            Usuario usuario = null;

            cursor.moveToFirst();
            @SuppressLint("Range") int id =  cursor.getInt(cursor.getColumnIndex("id"));
            @SuppressLint("Range") String login = cursor.getString(cursor.getColumnIndex("username"));

            usuario = new Usuario(login, id);

            cursor.close();
            db.close();
            Log.d("LOGIN NO BANCO", "" + cursor.getCount() + " Usuario: " + usuario.getLogin());
            return usuario;
        }
        catch(Exception e){
            Log.d("FALHA NO BANCO", e.getMessage());
        }

        return null;
    }
}
