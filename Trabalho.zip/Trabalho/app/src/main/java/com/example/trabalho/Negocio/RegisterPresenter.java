package com.example.trabalho.Negocio;

import com.example.trabalho.Modelo.DatabaseHelper;
import com.example.trabalho.Interface.RegistroActivity;
import com.example.trabalho.Modelo.RegisterInteractor;

public class RegisterPresenter {

    private RegisterInteractor registerInteractor;
    private RegistroActivity tela;

    public RegisterPresenter(DatabaseHelper db, RegistroActivity tela) {
        this.registerInteractor = new RegisterInteractor(db);
        this.tela = tela;
    }

    public void register(String nome, String dataNascimento, String email, String telefone,
                         String endereco, String username, String password) {
        if (isValidRegistration(nome, dataNascimento, email, telefone, endereco, username, password)) {
            boolean registrationResult = registerInteractor.performRegistration(nome, dataNascimento,
                    email, telefone, endereco, username, password);
            if (registrationResult) {
                tela.showRegistrationSuccess();
            } else {
                tela.showRegistrationError();
            }
        }
    }

    private boolean isValidRegistration(String nome, String dataNascimento, String email,
                                        String telefone, String endereco, String username, String password) {
        if (nome.isEmpty() || dataNascimento.isEmpty() || email.isEmpty() ||
                telefone.isEmpty() || endereco.isEmpty() || username.isEmpty() || password.isEmpty()) {
            return false;
        } else {
            return true;
        }
    }
}
