package com.example.trabalho.Modelo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
public class DatabaseHelper extends SQLiteOpenHelper {

    private DatabaseHelper databaseHelper;
    private SQLiteDatabase database;

    public static String TABLE_NAME_USER = "User";
    public static String COLUMN_ID = "id";
    public static String COLUMN_NOME = "nome";
    public static String COLUMN_DATA_NASCIMENTO = "data_nascimento";
    public static String COLUMN_EMAIL = "email";
    public static String COLUMN_TELEFONE = "telefone";
    public static String COLUMN_ENDERECO = "endereco";
    public static String COLUMN_USERNAME = "username";
    public static String COLUMN_PASSWORD = "password";

    public static String TABLE_NAME_FILME = "Filme";
    public static String COLUMN_ID_FILME = "id_filme";
    public static String COLUMN_TITULO = "titulo";
    public static String COLUMN_TITULO_ORIGINAL = "titulo_original";
    public static String COLUMN_DURACAO = "duracao";
    public static String COLUMN_DATA = "data";
    public static String COLUMN_SINOPSE = "sinopse";
    public static String COLUMN_ID_USUARIO = "id_usuario";

    public static final String DATABASE_NAME = "MyAppDatabase.sqlite3";
    public static final int DATABASE_VERSION = 1;

    public void setDatabaseHelper(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        criarTableUser(db);
        criarTableFilmes(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    public void criarTableUser(SQLiteDatabase db){
        
        String CREATE_TABLE_USER = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME_USER + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_NOME + " TEXT,"
                + COLUMN_DATA_NASCIMENTO + " TEXT,"
                + COLUMN_EMAIL + " TEXT,"
                + COLUMN_TELEFONE + " TEXT,"
                + COLUMN_ENDERECO + " TEXT,"
                + COLUMN_USERNAME + " TEXT,"
                + COLUMN_PASSWORD + " TEXT)";

        db.execSQL(CREATE_TABLE_USER);
    }

    public void criarTableFilmes(SQLiteDatabase db){

        String CREATE_TABLE_FILME = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME_FILME + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_ID_FILME + " INTEGER,"
                + COLUMN_TITULO + " TEXT,"
                + COLUMN_TITULO_ORIGINAL + " TEXT,"
                + COLUMN_DURACAO + " INTEGER,"
                + COLUMN_DATA + " TEXT,"
                + COLUMN_SINOPSE + " TEXT,"
                + COLUMN_ID_USUARIO + " INTEGER)";

        db.execSQL(CREATE_TABLE_FILME);
    }
}

