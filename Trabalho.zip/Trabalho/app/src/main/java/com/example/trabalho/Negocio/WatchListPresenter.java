package com.example.trabalho.Negocio;

import com.example.trabalho.Interface.WatchlistActivity;
import com.example.trabalho.Modelo.DatabaseHelper;
import com.example.trabalho.Modelo.Filme;
import com.example.trabalho.Modelo.WatchListInteractor;

import java.util.List;

public class WatchListPresenter {
    private WatchListInteractor watchListInteractor;
    private WatchlistActivity tela;

    public WatchListPresenter(DatabaseHelper db, WatchlistActivity tela) {
        this.watchListInteractor = new WatchListInteractor(db);
        this.tela = tela;
    }

    public List<Filme> getFilmesWatchlist(int idUsuario) {
        List<Filme> filmes = watchListInteractor.getFilmesWatchlist(idUsuario);
        return filmes;
    }
}
