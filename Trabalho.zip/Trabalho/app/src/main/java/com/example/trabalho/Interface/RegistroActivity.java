package com.example.trabalho.Interface;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.trabalho.Modelo.DatabaseHelper;
import com.example.trabalho.Negocio.RegisterPresenter;
import com.example.trabalho.R;

public class RegistroActivity extends AppCompatActivity {
        private EditText nomeEditText;
        private EditText dataNascimentoEditText;
        private EditText emailEditText;
        private EditText telefoneEditText;
        private EditText enderecoEditText;
        private EditText usernameEditText;
        private EditText passwordEditText;
        private Button registerButton;
        private RegisterPresenter registerPresenter;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_registro);

            DatabaseHelper db = new DatabaseHelper(RegistroActivity.this);

            nomeEditText = findViewById(R.id.nomeEditText);
            dataNascimentoEditText = findViewById(R.id.dataNascimentoEditText);
            emailEditText = findViewById(R.id.emailEditText);
            telefoneEditText = findViewById(R.id.telefoneEditText);
            enderecoEditText = findViewById(R.id.enderecoEditText);
            usernameEditText = findViewById(R.id.usernameEditText);
            passwordEditText = findViewById(R.id.passwordEditText);
            registerButton = findViewById(R.id.registerButton);

            registerPresenter = new RegisterPresenter(db, this);

            registerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String nome = nomeEditText.getText().toString();
                    String dataNascimento = dataNascimentoEditText.getText().toString();
                    String email = emailEditText.getText().toString();
                    String telefone = telefoneEditText.getText().toString();
                    String endereco = enderecoEditText.getText().toString();
                    String username = usernameEditText.getText().toString();
                    String password = passwordEditText.getText().toString();
                    registerPresenter.register(nome, dataNascimento, email, telefone, endereco, username, password);
                }
            });
        }

        public void showRegistrationSuccess() {
            Toast.makeText(this, getString(R.string.registroSucesso), Toast.LENGTH_SHORT).show();
            goToLogin();
        }

        public void goToLogin(){
            Intent intent = new Intent(RegistroActivity.this, MainActivity.class);
            startActivity(intent);
        }

        public void showRegistrationError() {
            Toast.makeText(this, getString(R.string.registroErro), Toast.LENGTH_SHORT).show();
        }
    }