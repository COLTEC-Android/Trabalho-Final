package com.example.trabalho.Interface;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Movie;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.trabalho.Modelo.Filme;
import com.example.trabalho.Modelo.MovieResult;
import com.example.trabalho.Modelo.RetrofitConfig;
import com.example.trabalho.Modelo.TMDBService;
import com.example.trabalho.Negocio.FilmeAdapter;
import com.example.trabalho.R;

import java.io.IOException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends AppCompatActivity {
    private FilmeAdapter adapter;
    private ListView moviesListView;
    private int pagina = 1;
    private String categoria = "popular";
    int idUsuario;
    private boolean temaClaro = true;

    private static int CURRENT_THEME = R.style.Theme_Trabalho;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setTheme(CURRENT_THEME);
        setContentView(R.layout.activity_home);

        if (CURRENT_THEME == R.style.Theme_TrabalhoNight) {
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            toolbar.setVisibility(View.VISIBLE);
            temaClaro = false;
        }

        realizarCall();
        moviesListView = findViewById(R.id.movie_list);

        idUsuario = getIdUser();

        moviesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Filme fimeSelecionado = (Filme) parent.getItemAtPosition(position);
                int filmeId = fimeSelecionado.getId();

                Intent intent = new Intent(HomeActivity.this, DetalhesFilmeActivity.class);
                intent.putExtra("filmeId", filmeId);
                intent.putExtra("idUsuario", idUsuario);
                intent.putExtra("idTema", CURRENT_THEME);
                startActivity(intent);
            }
        });

        Button btnProximaPagina = findViewById(R.id.btn_proxima_pagina);
        btnProximaPagina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                carregarProximaPagina();
            }
        });

        Button btnPaginaAnterior = findViewById(R.id.btn_pagina_anterior);
        btnPaginaAnterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                carregarPaginaAnterior();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_item1) {
            this.categoria = "popular";
            this.pagina = 1;
            realizarCall();
            return true;
        } else if (id == R.id.action_item2) {
            this.categoria = "upcoming";
            this.pagina = 1;
            realizarCall();
            return true;
        } else if (id == R.id.action_item3) {
            this.categoria = "now_playing";
            this.pagina = 1;
            realizarCall();
            return true;
        } else if (id == R.id.action_item4) {
            this.categoria = "top_rated";
            this.pagina = 1;
            realizarCall();
            return true;
        } else if (id == R.id.action_item5) {
            Intent intent = new Intent(HomeActivity.this, WatchlistActivity.class);
            intent.putExtra("idUsuario", idUsuario);
            intent.putExtra("idTema", CURRENT_THEME);
            startActivity(intent);
            return true;
        } else if (id == R.id.action_item6) {
            logout();
            return true;
        } else if (id == R.id.action_item7) {
            trocarTema();
        }

        return super.onOptionsItemSelected(item);
    }

    private void realizarCall() {
        TMDBService service = new RetrofitConfig().getTMDB();
        Call<MovieResult> call = service.getMovies(this.categoria, getString(R.string.idioma),"9a7309b982d88328bfe96f51882d43c0", this.pagina);

        call.enqueue(new Callback<MovieResult>() {
            @Override
            public void onResponse(Call<MovieResult> call, Response<MovieResult> response) {
                MovieResult results = response.body();
                List<Filme> listOfMovies = results.getResults();

                adapter = new FilmeAdapter(HomeActivity.this, listOfMovies);
                moviesListView.setAdapter(adapter);

                TextView tvPaginaAtual = findViewById(R.id.tv_pagina_atual);
                tvPaginaAtual.setText(getString(R.string.pagina) + " " + pagina);
            }

            @Override
            public void onFailure(Call<MovieResult> call, Throwable t) {

            }
        });
    }

    private void carregarProximaPagina() {
        this.pagina++;
        realizarCall();
    }

    private void carregarPaginaAnterior() {
        if (pagina > 1) {
            this.pagina --;
            realizarCall();
        } else {
            Toast.makeText(this, getString(R.string.primeiraPagina), Toast.LENGTH_SHORT).show();
        }
    }

    private int getIdUser() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        return preferences.getInt("id", -1);
    }

    private void logout() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.apply();

        Intent intent = new Intent(HomeActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void trocarTema() {
        temaClaro = !temaClaro;

        if (temaClaro) {
            switchActivityTheme(R.style.Theme_Trabalho);
        } else {
            switchActivityTheme(R.style.Theme_TrabalhoNight);
        }
    }

    private void switchActivityTheme(int themeId) {
        CURRENT_THEME = themeId;
        HomeActivity.this.finish();
        HomeActivity.this.startActivity(new Intent(HomeActivity.this, HomeActivity.class));
    }
}