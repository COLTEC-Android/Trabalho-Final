package com.example.trabalho.Negocio;

import com.example.trabalho.Modelo.DatabaseHelper;
import com.example.trabalho.Interface.MainActivity;
import com.example.trabalho.Modelo.LoginInteractor;
import com.example.trabalho.Modelo.Usuario;

public class LoginPresenter {
    private LoginInteractor loginInteractor;
    private MainActivity tela;

    public LoginPresenter(DatabaseHelper db, MainActivity tela) {
        loginInteractor = new LoginInteractor(db);
        this.tela = tela;
    }

    public void login(String username, String password) {

        if (isValidCredentials(username, password)) {
            Usuario usuario = loginInteractor.performLogin(username, password);
            if (usuario != null) {
                tela.showLoginSuccess(usuario);
            } else {
                tela.showLoginError();
            }
        }
    }

    private boolean isValidCredentials(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            return false;
        } else {
            return true;
        }
    }
}
