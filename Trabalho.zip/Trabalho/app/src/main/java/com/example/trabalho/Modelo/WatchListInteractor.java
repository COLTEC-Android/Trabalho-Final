package com.example.trabalho.Modelo;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class WatchListInteractor {
    private DatabaseHelper databaseHelper;
    public WatchListInteractor(DatabaseHelper db) {
        this.databaseHelper = db;
    }

    public List<Filme> getFilmesWatchlist(int idUsuario) {
        List<Filme> filmes = new ArrayList<>();

        String query = "SELECT * FROM Filme WHERE " + DatabaseHelper.COLUMN_ID_USUARIO + " = " + idUsuario;
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int filmeId = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ID_FILME));
                @SuppressLint("Range") String titulo = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_TITULO));
                @SuppressLint("Range") String tituloOriginal = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_TITULO_ORIGINAL));
                @SuppressLint("Range") int duracao = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_DURACAO));
                @SuppressLint("Range") String data = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DATA));
                @SuppressLint("Range") String sinopse = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_SINOPSE));

                Filme filme = new Filme();
                filme.setId(filmeId);
                filme.setTitle(titulo);
                filme.setOriginal_title(tituloOriginal);
                filme.setRuntime(duracao);
                filme.setRelease_date(data);
                filme.setOverview(sinopse);

                filmes.add(filme);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return filmes;
    }
}
