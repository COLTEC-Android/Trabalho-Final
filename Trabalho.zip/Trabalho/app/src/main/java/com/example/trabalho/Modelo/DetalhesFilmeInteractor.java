package com.example.trabalho.Modelo;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class DetalhesFilmeInteractor {
    private DatabaseHelper databaseHelper;
    public DetalhesFilmeInteractor(DatabaseHelper db) {
        this.databaseHelper = db;
    }

    public boolean adicionarFilme(Filme filme, int idUser) {

        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ID_FILME, filme.getId());
        values.put(DatabaseHelper.COLUMN_TITULO, filme.getTitle());
        values.put(DatabaseHelper.COLUMN_TITULO_ORIGINAL, filme.getOriginal_title());
        values.put(DatabaseHelper.COLUMN_DURACAO, filme.getRuntime());
        values.put(DatabaseHelper.COLUMN_DATA, filme.getRelease_date());
        values.put(DatabaseHelper.COLUMN_SINOPSE, filme.getOverview());
        values.put(DatabaseHelper.COLUMN_ID_USUARIO, idUser);

        long newRowId = db.insert(DatabaseHelper.TABLE_NAME_FILME, null, values);
        Log.d("INSERIR FILME NO BANCO" , "" + newRowId);

        return newRowId != -1;
    }

    public boolean isFilmeNaWatchList(Filme filme, int idUser) {

        String query = "SELECT COUNT(*) FROM " + DatabaseHelper.TABLE_NAME_FILME +
                " WHERE " + DatabaseHelper.COLUMN_ID_FILME + " = " + filme.getId() + " AND " + DatabaseHelper.COLUMN_ID_USUARIO + " = " + idUser;

        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery(query, null);
        if (cursor != null) {
            cursor.moveToFirst();
            int count = cursor.getInt(0);
            cursor.close();
            return count > 0;
        }
        return false;
    }

    public boolean removerFilme(int idUsuario, Filme filme) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        String tabelaFilmes = DatabaseHelper.TABLE_NAME_FILME;
        String colunaId = DatabaseHelper.COLUMN_ID_FILME;
        String colunaIdUsuario = DatabaseHelper.COLUMN_ID_USUARIO;

        String whereClause = colunaId + " = ? AND " + colunaIdUsuario + " = ?";

        String[] whereArgs = { String.valueOf(filme.getId()), String.valueOf(idUsuario) };

        int linhasAfetadas = db.delete(tabelaFilmes, whereClause, whereArgs);

        return linhasAfetadas > 0;
    }

}
