package com.example.trabalho.Negocio;

import com.example.trabalho.Interface.DetalhesFilmeActivity;
import com.example.trabalho.Modelo.DatabaseHelper;
import com.example.trabalho.Modelo.Filme;
import com.example.trabalho.Modelo.DetalhesFilmeInteractor;

public class DetalhesFilmePresenter {
    private DetalhesFilmeInteractor detalhesFilmeInteractor;
    private DetalhesFilmeActivity tela;

    public DetalhesFilmePresenter(DatabaseHelper db, DetalhesFilmeActivity tela) {
        this.detalhesFilmeInteractor = new DetalhesFilmeInteractor(db);
        this.tela = tela;
    }

    public void adicionarFilme(Filme filme, int idUser){
        boolean result = detalhesFilmeInteractor.adicionarFilme(filme, idUser);
        if (result) {
            tela.showAddSuccess();
        } else {
            tela.showAddError();
        }
    }


    public void removerFilme(Filme filme, int idUser) {
        boolean removido = detalhesFilmeInteractor.removerFilme(idUser, filme);
        if (removido) {
            tela.showRemoveSuccess();
        } else {
            tela.showRemoveError();
        }
    }



    public boolean isFilmeNaWatchList(Filme filme, int idUser) {
         return detalhesFilmeInteractor.isFilmeNaWatchList(filme, idUser);
    }
}
