package com.example.trabalho.Interface;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import java.io.InputStream;
import java.net.URL;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.widget.TextView;
import android.widget.Toast;

import com.example.trabalho.Modelo.DatabaseHelper;
import com.example.trabalho.Modelo.Filme;
import com.example.trabalho.Modelo.RetrofitConfig;
import com.example.trabalho.Modelo.TMDBService;
import com.example.trabalho.Negocio.DetalhesFilmePresenter;
import com.example.trabalho.R;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetalhesFilmeActivity extends AppCompatActivity {
    private Filme result;

    private ImageView imageView;
    private TextView titulo;
    private TextView tituloOriginal;
    private TextView data;
    private TextView revenue;
    private TextView generoId;
    private TextView avaliacao;
    private TextView tempoExibicao;
    private TextView sinopse;
    private ImageButton adicionarWL;
    private ImageButton removerWL;

    private DetalhesFilmePresenter detalhesFilmePresenter;

    private int idUsuario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int idTema = getIntent().getIntExtra("idTema", 0);
        this.setTheme(idTema);
        setContentView(R.layout.activity_detalhes_filme);

        DatabaseHelper db = new DatabaseHelper(DetalhesFilmeActivity.this);
        detalhesFilmePresenter = new DetalhesFilmePresenter(db, this);
        inicializarComponentes();

        idUsuario = getIntent().getIntExtra("idUsuario", 0);
        int filmeId = getIntent().getIntExtra("filmeId", 0);
        TMDBService service = new RetrofitConfig().getTMDB();
        Call<Filme> call = service.getMovie(filmeId, getString(R.string.idioma),"9a7309b982d88328bfe96f51882d43c0");

        call.enqueue(new Callback<Filme>() {
            @Override
            public void onResponse(Call<Filme> call, Response<Filme> response) {
                result = response.body();
                List<Filme.genero> listaGeneros = result.getGenres();
                String generos = "";
                for(int i = 0; i < listaGeneros.size(); i++){
                    generos = generos + listaGeneros.get(i). getName() + " ";
                }
                String url = "https://image.tmdb.org/t/p/w500";
                new LoadImageTask().execute(url + result.getPoster_path());

                titulo.setText(getString(R.string.titulo) + result.getTitle());
                tituloOriginal.setText(getString(R.string.tituloOriginal) + result.getOriginal_title());
                data.setText(getString(R.string.dataLancamento) + result.getRelease_date());
                revenue.setText(getString(R.string.receita) + String.valueOf(result.getRevenue()));
                generoId.setText(getString(R.string.genero) + generos);
                avaliacao.setText(getString(R.string.avaliacao) + String.valueOf(result.getVote_average()));
                tempoExibicao.setText(getString(R.string.duracao) +  String.valueOf(result.getRuntime()) + getString(R.string.minutos));
                sinopse.setText(getString(R.string.sinopse) + result.getOverview());

                if (detalhesFilmePresenter.isFilmeNaWatchList(result, idUsuario)) {
                    adicionarWL.setVisibility(View.INVISIBLE);
                    removerWL.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<Filme> call, Throwable t) {

            }
        });

        adicionarWL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detalhesFilmePresenter.adicionarFilme(result, idUsuario);
                adicionarWL.setVisibility(View.INVISIBLE);
                removerWL.setVisibility(View.VISIBLE);
            }
        });

        removerWL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detalhesFilmePresenter.removerFilme(result, idUsuario);
                adicionarWL.setVisibility(View.VISIBLE);
                removerWL.setVisibility(View.INVISIBLE);
            }
        });

    }

    public void inicializarComponentes(){
        imageView = findViewById(R.id.imageView);
        titulo = findViewById(R.id.titleTextView);
        tituloOriginal = findViewById(R.id.originalTitleTextView);
        data = findViewById(R.id.releaseDateTextView);
        revenue = findViewById(R.id.revenueTextView);
        generoId = findViewById(R.id.genreIdTextView);
        avaliacao = findViewById(R.id.vote_avarageTextView);
        tempoExibicao = findViewById(R.id.runTimeTextView);
        sinopse = findViewById(R.id.sinopseTextView);
        adicionarWL = findViewById(R.id.adicionarButton);
        removerWL = findViewById(R.id.removerButton);
    }

    private class LoadImageTask extends AsyncTask<String, Void, Bitmap> {

        @Override
        protected Bitmap doInBackground(String... params) {
            String imageUrl = params[0];
            Bitmap bitmap = null;
            try {
                InputStream inputStream = new URL(imageUrl).openStream();
                bitmap = BitmapFactory.decodeStream(inputStream);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if (bitmap != null) {
                imageView.setImageBitmap(bitmap);
            }
        }
    }

    public void showAddSuccess() {
        Toast.makeText(this, getString(R.string.adicionado), Toast.LENGTH_SHORT).show();
    }

    public void showAddError() {
        Toast.makeText(this, getString(R.string.erroAdicionar), Toast.LENGTH_SHORT).show();
    }

    public void showRemoveSuccess() {
        Toast.makeText(this, getString(R.string.removido), Toast.LENGTH_SHORT).show();
    }

    public void showRemoveError() {
        Toast.makeText(this, getString(R.string.erroRemover), Toast.LENGTH_SHORT).show();
    }
}