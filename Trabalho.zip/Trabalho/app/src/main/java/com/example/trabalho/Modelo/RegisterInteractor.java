package com.example.trabalho.Modelo;
//interage com o bd

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class RegisterInteractor {

    private DatabaseHelper databaseHelper;
    public RegisterInteractor(DatabaseHelper db) {
        this.databaseHelper = db;
    }
    public boolean performRegistration(String nome, String dataNascimento, String email,
                                       String telefone, String endereco, String username, String password) {

        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_NOME, nome);
        values.put(DatabaseHelper.COLUMN_DATA_NASCIMENTO, dataNascimento);
        values.put(DatabaseHelper.COLUMN_EMAIL, email);
        values.put(DatabaseHelper.COLUMN_TELEFONE, telefone);
        values.put(DatabaseHelper.COLUMN_ENDERECO, endereco);
        values.put(DatabaseHelper.COLUMN_USERNAME, username);
        values.put(DatabaseHelper.COLUMN_PASSWORD, password);

        long newRowId = db.insert(DatabaseHelper.TABLE_NAME_USER, null, values);
        Log.d("INSERIR NO BANCO" , "" + newRowId);

        return newRowId != -1;
    }
}