package com.example.trabalho.Interface;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.trabalho.Modelo.DatabaseHelper;
import com.example.trabalho.Modelo.Usuario;
import com.example.trabalho.Negocio.LoginPresenter;
import com.example.trabalho.R;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private LoginPresenter loginPresenter;
    private Button registerButton;
    private String username;
    private String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String databasePath = getApplicationContext().getDatabasePath(DatabaseHelper.DATABASE_NAME).getAbsolutePath();
        Log.d("Database Path", databasePath);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (isUserLoggedIn()) {
            goToHome();
            finish();
            return;
        }

        inicializarComponentes();

        DatabaseHelper db = new DatabaseHelper(MainActivity.this);
        loginPresenter = new LoginPresenter(db, this);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username = usernameEditText.getText().toString();
                password = passwordEditText.getText().toString();
                loginPresenter.login(username, password);
            }
        });
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RegistroActivity.class);
                startActivity(intent);
            }
        });
    }

    public void showLoginSuccess(Usuario usuario) {
        setLoggedIn(true);
        saveUserInfo(usuario);
        goToHome();
        finish();
    }

    public void showLoginError() {
        Toast.makeText(this, "Login failed", Toast.LENGTH_SHORT).show();
    }

    public void goToHome(){
        Intent intent = new Intent(MainActivity.this, HomeActivity.class);
        startActivity(intent);
    }

    public void inicializarComponentes(){
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);
    }

    private boolean isUserLoggedIn() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        boolean isLoggedIn = preferences.getBoolean("isLoggedIn", false);
        return isLoggedIn;
    }

    private void setLoggedIn(boolean isLoggedIn) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("isLoggedIn", isLoggedIn);
        editor.apply();
    }

    private void saveUserInfo(Usuario usuario) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("login", usuario.getLogin());
        editor.putInt("id", usuario.getId());
        editor.apply();
    }
}