package com.example.trabalho;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.trabalho.Modelo.DatabaseHelper;
import com.example.trabalho.Modelo.Filme;
import com.example.trabalho.Modelo.WatchListInteractor;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class WatchListInteractorTest {

    @Mock
    private DatabaseHelper databaseHelper;

    @Mock
    private SQLiteDatabase sqLiteDatabase;

    private WatchListInteractor watchListInteractor;

    @Before
    public void setup() {
        watchListInteractor = new WatchListInteractor(databaseHelper);
        when(databaseHelper.getReadableDatabase()).thenReturn(sqLiteDatabase);
    }

    @Test
    public void testGetFilmesWatchlist() {
        // Configuração
        int idUsuario = 1;

        Cursor cursor = Mockito.mock(Cursor.class);
        when(cursor.moveToFirst()).thenReturn(true);
        when(cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ID_FILME))).thenReturn(1);
        when(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_TITULO))).thenReturn("Filme 1");
        when(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_TITULO_ORIGINAL))).thenReturn("Original 1");
        when(cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_DURACAO))).thenReturn(120);
        when(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DATA))).thenReturn("2023-01-01");
        when(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_SINOPSE))).thenReturn("Sinopse 1");
        when(sqLiteDatabase.rawQuery(Mockito.anyString(), Mockito.isNull())).thenReturn(cursor);

        // Execução
        List<Filme> filmes = watchListInteractor.getFilmesWatchlist(idUsuario);

        // Verificação
        verify(sqLiteDatabase).rawQuery(Mockito.anyString(), Mockito.isNull());
        verify(cursor).close();

        assertEquals(1, filmes.size());
        Filme filme = filmes.get(0);
        assertEquals(1, filme.getId());
        assertEquals("Filme 1", filme.getTitle());
        assertEquals("Original 1", filme.getOriginal_title());
        assertEquals(120, filme.getRuntime());
        assertEquals("2023-01-01", filme.getRelease_date());
        assertEquals("Sinopse 1", filme.getOverview());
    }

    @Test
    public void testGetFilmesWatchlist_NoFilmes() {
        // Configuração
        int idUsuario = 1;

        Cursor cursor = Mockito.mock(Cursor.class);
        when(cursor.moveToFirst()).thenReturn(false);
        when(sqLiteDatabase.rawQuery(Mockito.anyString(), Mockito.isNull())).thenReturn(cursor);

        // Execução
        List<Filme> filmes = watchListInteractor.getFilmesWatchlist(idUsuario);

        // Verificação
        verify(sqLiteDatabase).rawQuery(Mockito.anyString(), Mockito.isNull());
        verify(cursor).close();

        assertEquals(0, filmes.size());
    }
}
