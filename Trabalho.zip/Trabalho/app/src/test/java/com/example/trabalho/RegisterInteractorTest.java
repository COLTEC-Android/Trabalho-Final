package com.example.trabalho;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

import com.example.trabalho.Modelo.DatabaseHelper;
import com.example.trabalho.Modelo.RegisterInteractor;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class RegisterInteractorTest {

    @Mock
    private DatabaseHelper databaseHelper;

    @Mock
    private SQLiteDatabase sqLiteDatabase;

    private RegisterInteractor registerInteractor;

    @Before
    public void setup() {
        registerInteractor = new RegisterInteractor(databaseHelper);
        Mockito.when(databaseHelper.getWritableDatabase()).thenReturn(sqLiteDatabase);
    }

    @Test
    public void testPerformRegistration() {
        // Configuração
        String nome = "Joao";
        String dataNascimento = "1990-01-01";
        String email = "joao@email.com";
        String telefone = "123456789";
        String endereco = "rua 123";
        String username = "joao";
        String password = "senha123";

        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.COLUMN_NOME, nome);
        contentValues.put(DatabaseHelper.COLUMN_DATA_NASCIMENTO, dataNascimento);
        contentValues.put(DatabaseHelper.COLUMN_EMAIL, email);
        contentValues.put(DatabaseHelper.COLUMN_TELEFONE, telefone);
        contentValues.put(DatabaseHelper.COLUMN_ENDERECO, endereco);
        contentValues.put(DatabaseHelper.COLUMN_USERNAME, username);
        contentValues.put(DatabaseHelper.COLUMN_PASSWORD, password);

        Mockito.when(sqLiteDatabase.insert(Mockito.anyString(), Mockito.isNull(), Mockito.any(ContentValues.class)))
                .thenReturn(1L);

        // Execução
        boolean resultado = registerInteractor.performRegistration(nome, dataNascimento, email,
                telefone, endereco, username, password);

        // Verificação
        assertTrue(resultado);
        Mockito.verify(sqLiteDatabase).insert(Mockito.anyString(), Mockito.isNull(), Mockito.any(ContentValues.class));
        Mockito.verify(sqLiteDatabase).close();
    }
}
