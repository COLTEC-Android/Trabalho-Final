package com.example.trabalho;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.trabalho.Modelo.DatabaseHelper;
import com.example.trabalho.Modelo.DetalhesFilmeInteractor;
import com.example.trabalho.Modelo.Filme;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class DetalhesFilmeInteractorTest {

    @Mock
    private DatabaseHelper databaseHelper;

    @Mock
    private SQLiteDatabase sqLiteDatabase;

    private DetalhesFilmeInteractor detalhesFilmeInteractor;

    @Before
    public void setup() {
        detalhesFilmeInteractor = new DetalhesFilmeInteractor(databaseHelper);
        Mockito.when(databaseHelper.getWritableDatabase()).thenReturn(sqLiteDatabase);
        Mockito.when(databaseHelper.getReadableDatabase()).thenReturn(sqLiteDatabase);
    }

    @Test
    public void testAdicionarFilme() {
        // Configuração
        Filme filme = new Filme();
        filme.setId(1);
        filme.setTitle("Filme Teste");
        int idUser = 1;

        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.COLUMN_ID_FILME, filme.getId());
        contentValues.put(DatabaseHelper.COLUMN_TITULO, filme.getTitle());
        // Adicione mais valores para as outras colunas, se necessário

        Mockito.when(sqLiteDatabase.insert(Mockito.anyString(), Mockito.isNull(), Mockito.any(ContentValues.class)))
                .thenReturn(1L);

        // Execução
        boolean resultado = detalhesFilmeInteractor.adicionarFilme(filme, idUser);

        // Verificação
        assertTrue(resultado);
        Mockito.verify(sqLiteDatabase).insert(Mockito.anyString(), Mockito.isNull(), Mockito.any(ContentValues.class));
    }

    @Test
    public void testIsFilmeNaWatchList() {
        // Configuração
        Filme filme = new Filme();
        filme.setId(1);
        int idUser = 1;

        Cursor cursor = Mockito.mock(Cursor.class);
        Mockito.when(cursor.moveToFirst()).thenReturn(true);
        Mockito.when(cursor.getInt(0)).thenReturn(1);
        Mockito.when(sqLiteDatabase.rawQuery(Mockito.anyString(), Mockito.isNull())).thenReturn(cursor);

        // Execução
        boolean resultado = detalhesFilmeInteractor.isFilmeNaWatchList(filme, idUser);

        // Verificação
        assertTrue(resultado);
        Mockito.verify(sqLiteDatabase).rawQuery(Mockito.anyString(), Mockito.isNull());
        Mockito.verify(cursor).close();
    }

    @Test
    public void testRemoverFilme() {
        // Configuração
        Filme filme = new Filme();
        filme.setId(1);
        int idUser = 1;

        String tabelaFilmes = DatabaseHelper.TABLE_NAME_FILME;
        String colunaId = DatabaseHelper.COLUMN_ID_FILME;
        String colunaIdUsuario = DatabaseHelper.COLUMN_ID_USUARIO;
        String whereClause = colunaId + " = ? AND " + colunaIdUsuario + " = ?";
        String[] whereArgs = { String.valueOf(filme.getId()), String.valueOf(idUser) };

        Mockito.when(sqLiteDatabase.delete(tabelaFilmes, whereClause, whereArgs)).thenReturn(1);

        // Execução
        boolean resultado = detalhesFilmeInteractor.removerFilme(idUser, filme);

        // Verificação
        assertTrue(resultado);
        Mockito.verify(sqLiteDatabase).delete(tabelaFilmes, whereClause, whereArgs);
    }

    @Test
    public void testRemoverFilme_NenhumFilmeRemovido() {
        // Configuração
        Filme filme = new Filme();
        filme.setId(1);
        int idUser = 1;

        String tabelaFilmes = DatabaseHelper.TABLE_NAME_FILME;
        String colunaId = DatabaseHelper.COLUMN_ID_FILME;
        String colunaIdUsuario = DatabaseHelper.COLUMN_ID_USUARIO;
        String whereClause = colunaId + " = ? AND " + colunaIdUsuario + " = ?";
        String[] whereArgs = { String.valueOf(filme.getId()), String.valueOf(idUser) };

        Mockito.when(sqLiteDatabase.delete(tabelaFilmes, whereClause, whereArgs)).thenReturn(0);

        // Execução
        boolean resultado = detalhesFilmeInteractor.removerFilme(idUser, filme);

        // Verificação
        assertFalse(resultado);
        Mockito.verify(sqLiteDatabase).delete(tabelaFilmes, whereClause, whereArgs);
    }
}
