package com.example.trabalho;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.trabalho.Modelo.DatabaseHelper;
import com.example.trabalho.Modelo.LoginInteractor;
import com.example.trabalho.Modelo.Usuario;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

@RunWith(MockitoJUnitRunner.class)
public class LoginInteractorTest {

    @Mock
    private DatabaseHelper databaseHelper;

    @Mock
    private SQLiteDatabase sqLiteDatabase;

    private LoginInteractor loginInteractor;

    @Before
    public void setup() {
        loginInteractor = new LoginInteractor(databaseHelper);
        Mockito.when(databaseHelper.getReadableDatabase()).thenReturn(sqLiteDatabase);
    }

    @Test
    public void testPerformLogin_WithValidCredentials() {
        // Configuração
        String username = "user";
        String password = "password";

        Cursor cursor = Mockito.mock(Cursor.class);
        Mockito.when(cursor.moveToFirst()).thenReturn(true);
        Mockito.when(cursor.getColumnIndex(DatabaseHelper.COLUMN_ID)).thenReturn(0);
        Mockito.when(cursor.getColumnIndex(DatabaseHelper.COLUMN_USERNAME)).thenReturn(1);
        Mockito.when(cursor.getInt(0)).thenReturn(1);
        Mockito.when(cursor.getString(1)).thenReturn(username);
        Mockito.when(sqLiteDatabase.query(Mockito.anyString(), Mockito.any(String[].class),
                Mockito.anyString(), Mockito.any(String[].class), Mockito.isNull(), Mockito.isNull(),
                Mockito.isNull())).thenReturn(cursor);

        // Execução
        Usuario usuario = loginInteractor.performLogin(username, password);

        // Verificação
        assertEquals(username, usuario.getLogin());
        assertEquals(1, usuario.getId());
        Mockito.verify(sqLiteDatabase).query(Mockito.anyString(), Mockito.any(String[].class),
                Mockito.anyString(), Mockito.any(String[].class), Mockito.isNull(), Mockito.isNull(),
                Mockito.isNull());
        Mockito.verify(cursor).close();
        Mockito.verify(sqLiteDatabase).close();
    }

    @Test
    public void testPerformLogin_WithInvalidCredentials() {
        // Configuração
        String username = "user";
        String password = "password";

        Cursor cursor = Mockito.mock(Cursor.class);
        Mockito.when(cursor.moveToFirst()).thenReturn(false);
        Mockito.when(sqLiteDatabase.query(Mockito.anyString(), Mockito.any(String[].class),
                Mockito.anyString(), Mockito.any(String[].class), Mockito.isNull(), Mockito.isNull(),
                Mockito.isNull())).thenReturn(cursor);

        // Execução
        Usuario usuario = loginInteractor.performLogin(username, password);

        // Verificação
        assertNull(usuario);
        Mockito.verify(sqLiteDatabase).query(Mockito.anyString(), Mockito.any(String[].class),
                Mockito.anyString(), Mockito.any(String[].class), Mockito.isNull(), Mockito.isNull(),
                Mockito.isNull());
        Mockito.verify(cursor).close();
        Mockito.verify(sqLiteDatabase).close();
    }
}
