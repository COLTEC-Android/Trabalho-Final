package com.example.trabalho;

import com.example.trabalho.Interface.MainActivity;
import com.example.trabalho.Modelo.DatabaseHelper;
import com.example.trabalho.Modelo.LoginInteractor;
import com.example.trabalho.Modelo.Usuario;
import com.example.trabalho.Negocio.LoginPresenter;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class LoginPresenterTest {

    @Mock
    private DatabaseHelper databaseHelper;

    @Mock
    private MainActivity mainActivity;

    @Mock
    private LoginInteractor loginInteractor;

    private LoginPresenter loginPresenter;

    @Before
    public void setup() {
        loginPresenter = new LoginPresenter(databaseHelper, mainActivity);
        String username = "";
        int id = -1;
        Mockito.when(loginInteractor.performLogin(Mockito.anyString(), Mockito.anyString())).thenReturn(new Usuario(username, id));
    }

    @Test
    public void testLogin_Success() {
        // Configuração
        String username = "joao@";
        String password = "password";

        // Execução
        loginPresenter.login(username, password);

        // Verificação
        verify(mainActivity).showLoginSuccess(Mockito.any(Usuario.class));
    }

    @Test
    public void testLogin_Error() {
        // Configuração
        String username = "joao";
        String password = "password";

        Mockito.when(loginInteractor.performLogin(Mockito.anyString(), Mockito.anyString())).thenReturn(null);

        // Execução
        loginPresenter.login(username, password);

        // Verificação
        verify(mainActivity).showLoginError();
    }

    @Test
    public void testLogin_InvalidCredentials() {
        // Configuração
        String username = "";
        String password = "password";

        // Execução
        loginPresenter.login(username, password);

        // Verificação
        Mockito.verifyNoMoreInteractions(mainActivity);
    }
}
